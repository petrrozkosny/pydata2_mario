


class Student():
    def __init__(change):
        print('halooo')

petr = Student()
iva = Student()

