def zobraz_detail_lokality(change):
    with output:  # Kontextový manažer pro práci s výstupním widgetem
        output.clear_output()  # Vyčistí aktuální obsah výstupního widgetu
        lokalita = menu_lokalita.value  # Získání vybrané lokality z dropdown menu
        # Výpis statistik pro zvolenou lokalitu
        display(df[df['NAME'] == lokalita].describe())  # Zobrazení statistik pro vybranou lokalitu