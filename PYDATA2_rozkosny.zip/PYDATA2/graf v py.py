import pandas as pd
import matplotlib.pyplot as plt


# Načtení dat
df = pd.read_csv('https://raw.githubusercontent.com/petrrozkosny/pydata/main/pydata_data.csv', delimiter=';')



# Převod na datetime a extrakce roku
df['DATE'] = pd.to_datetime(df['DATE'])
df['YEAR'] = df['DATE'].dt.year


# Agregace dle ROK, sum PRCP

df = df.groupby('YEAR')['PRCP'].sum().reset_index()
prum_prcp = df['PRCP'].mean()
df['PRCP MEAN'] = prum_prcp
ax = df.plot(x='YEAR',y='PRCP')
ax.axhline(y=prum_prcp,color = 'red')
plt.savefig('obrazek.png')

