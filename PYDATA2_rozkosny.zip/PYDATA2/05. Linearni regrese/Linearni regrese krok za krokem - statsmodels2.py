
'''
Pokud máme ambici vytvořit model, který predikuje hodnoty závislé proměnné
 na základě hodnot nezávislé proměnné,
je důležité rozdělit data na trénovací a testovací množinu.
Trénovací množina slouží k natrénování modelu, zatímco testovací množina slouží k ověření,
jak dobře model predikuje hodnoty závislé proměnné na základě hodnot nezávislé proměnné.
Zjišťujeme koeficienty modelu na dosud neviděných datech.
'''

import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
import statsmodels.api as sm
import numpy as np




import pandas as pd
import statsmodels.api as sm
from sklearn.model_selection import train_test_split

# Vytvoření DataFrame
data = pd.DataFrame({
# Nezávislá proměnná (X)
'Hodiny_studia': [1, 2, 3, 4, 5, 6, 7, 8, 9, 10],
# Závislá proměnná (Y)
'Body_na_zkousce': [2, 4, 5, 4, 5, 6, 7, 8, 8, 9]
})

# Rozdělení dat na trénovací a testovací sady
X = data['Hodiny_studia']
y = data['Body_na_zkousce']
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2)

# Přidání konstanty pro model
X_train = sm.add_constant(X_train)

# Vytvoření a trénování modelu lineární regrese
model = sm.OLS(y_train, X_train)
results = model.fit()

# Ověření modelu na testovací sadě
X_test = sm.add_constant(X_test)
y_pred = results.predict(X_test)

# Výpočet koeficientů
print("Koeficienty modelu:")
print(results.params)

# Uživatel zadává vlastní hodnotu nezávislé proměnné
vstup = int(input("Zadejte hodnotu nezávislé proměnné: "))

# Přidání konstanty k vstupním datům uživatele
vstup_s_konstantou = sm.add_constant([1,vstup])

# Předpověď hodnoty závislé proměnné
predikce = results.predict(vstup_s_konstantou)
print("Předpovězená hodnota závislé proměnné:", predikce[0])
