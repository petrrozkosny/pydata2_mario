# Import potřebných knihoven
import pandas as pd


def linearni_regrese1():

    # Vytvoření datasetu jako pandas DataFrame
    data = pd.DataFrame({
        # Nezávislá proměnná (X)
        'Hodiny_studia': [1, 2, 3, 4, 5, 6, 7, 8, 9, 10],
        # Závislá proměnná (Y)
        'Body_na_zkousce': [2, 4, 5, 4, 5, 6, 7, 8, 8, 9]
    })

    # Výpočet průměrů pomocí pandas
    prumer_X = data['Hodiny_studia'].mean() # Průměr nezávislé proměnné x
    prumer_Y = data['Body_na_zkousce'].mean() # Průměr závislé proměnné y


    sum_xy = (
        (
            # Od každé hodnoty x (nezávislá proměnná) se odečte průměr x 
            (data['Hodiny_studia'] - prumer_X)
            * 
            # Od každé hodnoty y (závislá proměnná) se odečte průměr y  
            (data['Body_na_zkousce'] - prumer_Y)).sum()
    )


    sum_xx = (
        # Od každé hodnoty x (nezávislá proměnná) se odečte průměr x a výsledek se umocní na druhou
        ((data['Hodiny_studia'] - prumer_X) ** 2).sum()
    )

    # Výpočet směrnice (b) regresní přímky, tj. o kolik se změní y, když se změní x o jednotku
    b = sum_xy / sum_xx
    # Výpočet y-interceptu (a) regresní přímky, tj. hodnota y, když x = 0
    a = prumer_Y - b * prumer_X

    # Výpočet predikovaných hodnot Y (Y_hat) pomocí regresního modelu,
    # tj. počet hodin studia vynásobíme směrnicí a přičteme y-intercept
    data['Y_hat'] = a + b * data['Hodiny_studia']

    # Výpočet sum čtverců pro analýzu rozptylu
    # Rozptyl je statistický ukazatel vyjadřující míru variability hodnot v rámci množiny (v našem případě sloupci dataframe)

    # Výpočet SSR (Sum of Squares Regression), tj. součet čtverců regrese, od každé predikované hodnoty se odečte průměr Y a výsledek se umocní na druhou,
    # čímž získáme součet čtverců regrese, který vyjadřuje, jak moc jsou predikované hodnoty odlišné od průměru Y,
    # získáváme informaci, jak moc je regresní přímka schopná vysvětlit rozptyl závislé proměnné.
    # Čím je SSR větší, tím lépe regresní přímka vysvětluje rozptyl závislé proměnné.
    SSR = ((data['Y_hat'] - prumer_Y) ** 2).sum()

    # Výpočet SSE (Sum of Squares Error), tj. součet čtverců chyb, od každé hodnoty Y se odečte predikovaná hodnota Y a výsledek se umocní na druhou,
    # Tímto získáme součet chyb (rozdílů mezi predikovanými a reálnými hodnotami Y), který vyjadřuje, jak moc jsou predikované hodnoty odlišné od reálných hodnot Y.
    # Čím vyšší SSE, tím horší je regresní přímka schopná vysvětlit rozptyl závislé proměnné.
    SSE = ((data['Body_na_zkousce'] - data['Y_hat']) ** 2).sum()

    # Výpočet SST (Sum of Squares Total), tj. součet čtverců celkový, od každé hodnoty Y se odečte průměr Y a výsledek se umocní na druhou.
    # Tímto získáme součet čtverců celkový, který vyjadřuje, jak moc jsou hodnoty Y odlišné od průměru Y.
    # Čím vyšší SST, tím větší je celkový rozptyl závislé proměnné.
    SST = ((data['Body_na_zkousce'] - prumer_Y) ** 2).sum()

    # Výpočet R-squared, tj. koeficient determinace, který vyjadřuje, jak moc je regresní přímka schopná vysvětlit rozptyl závislé proměnné.
    # Čím je R-squared blíže k 1, tím lépe regresní přímka vysvětluje rozptyl závislé proměnné.
    # Čím je R-squared blíže k 0, tím horší je regresní přímka schopná vysvětlit rozptyl závislé proměnné.
    # R-squared může nabývat hodnot od 0 do 1.
    R_squared = 1 - (SSE / SST)

    # Výpočet stupňů volnosti, máme 1 nezávislou proměnnou, tedy df_model = 1
    df_model = 1

    # Výpočet stupňů volnosti, máme 5 pozorování, tedy df_residuals = 5 - 1 - 1 = 3
    df_residuals = data.shape[0] - df_model - 1

    # Výpočet MSE a MSR

    # Výpočet MSE (Mean Squared Error), tj. průměrná chyba čtverců, která vyjadřuje, jak moc jsou predikované hodnoty odlišné od reálných hodnot Y.
    # Zatímco SSE vyjadřuje chybovost za model, MSE vyjadřuje chybovost za jedno pozorování (jednu hodnotu Y).
    # Slouží k přesnějšímu vyjádření chybovosti modelu.
    MSE = SSE / df_residuals
    # Výpočet MSR (Mean Squared Regression), tj. průměrný čtverec regrese, který vyjadřuje, jak moc je regresní přímka schopná vysvětlit rozptyl závislé proměnné.
    # Zatímco SSR vyjadřuje schopnost regresní přímky vysvětlit rozptyl závislé proměnné, MSR vyjadřuje schopnost regresní přímky vysvětlit rozptyl závislé proměnné za jedno pozorování (jednu hodnotu Y).
    # Slouží k přesnějšímu vyjádření schopnosti regresní přímky vysvětlit rozptyl závislé proměnné.
    MSR = SSR / df_model

    # Výpočet F-statistiky
    # F-statistika je statistický ukazatel, který vyjadřuje statistickou významnost regresního modelu.
    # Čím je F-statistika vyšší, tím větší je statistická významnost regresního modelu.
    # V praxi se můžeme setkat s tím, že máme nízká R-squared, ale vysoká F-statistika, což znamená, že i když regresní přímka vysvětluje jen malou část rozptylu závislé proměnné, je statisticky významná.
    # Naopak můžeme mít vysoké R-squared, ale nízkou F-statistiku, což znamená, že i když regresní přímka vysvětluje většinu rozptylu závislé proměnné, není statisticky významná,
    # F-statistika vychází z nulové hypotézy, že všechny koeficienty regresního modelu jsou nulové, tedy že regresní model není statisticky významný,
    # na nás je pak tuto nulovou hypotézu otestovat právě za pomoci F-statistiky.
    F_statistic = MSR / MSE

    # Výpis výsledků
    print(f"Směrnice (b): {b}")
    print(f"Y-intercept (a): {a}")
    print(f"R-squared: {R_squared}")
    print(f"F-statistika: {F_statistic}")


def linearni_regrese2():
    import statsmodels.api as sm

    # Vytvoření datasetu jako pandas DataFrame
    data = pd.DataFrame({
        # Nezávislá proměnná (X)
        'Hodiny_studia': [1, 2, 3, 4, 5, 6, 7, 8, 9, 10],
        # Závislá proměnná (Y)
        'Body_na_zkousce': [2, 4, 5, 4, 5, 6, 7, 8, 8, 9]
    })

    # Příprava dat pro model
    X = data['Hodiny_studia']
    X = sm.add_constant(X)  # Přidání sloupce pro intercept
    Y = data['Body_na_zkousce']

    # Vytvoření a fitování modelu
    model = sm.OLS(Y, X).fit()

    # Výsledky modelu
    # print(model.summary())




    # Ověření modelu na testovací sadě
    X_test = sm.add_constant([[1,10]])
    y_pred = model.predict(X_test)
        
        
    print(y_pred)    
    
    # print(model.pvalues)

    '''
    Intercept (const) p-hodnota 0.001421: Tato p-hodnota znamená, že existuje přibližně 0.142% pravděpodobnost,
    že bychom pozorovali stejnou nebo více extrémní hodnotu koeficientu, pokud by skutečný vliv interceptu byl nulový.
    Protože tato pravděpodobnost je menší než obvyklý práh statistické významnosti 5% (0.05),
    můžeme odmítnout nulovou hypotézu, a tedy existuje dostatečný důkaz pro tvrzení,
    že intercept má statisticky významný efekt na závislou proměnnou.

    Hodiny_studia p-hodnota 0.000005: Zde existuje  0.0005% pravděpodobnost,
    že bychom pozorovali stejnou nebo více extrémní hodnotu koeficientu,
    pokud by skutečný vliv hodin studia byl nulový.
    Nepřekročení prahu 5% znamená, že existuje dostatečný důkaz pro odmítnutí nulové hypotézy,
    můžeme statisticky potvrdit, že počet hodin studia má významný vliv na body na zkoušce.
    '''

#linearni_regrese1()
linearni_regrese2()

